# TabTimeTracker
 Tracks the amount of time spent on each tab in Firefox.
